doitGROMACS
===========

write README

